# PSG Session Maker — Déploiement Vercel

Glisse simplement ce dossier sur https://vercel.com/new pour déployer.

## Fichiers
- `index.html` : le dashboard principal (page d'accueil)
- `vercel.json` : config de déploiement (cache désactivé pour MAJ rapide)

## Mise à jour
Pour déployer une nouvelle version : remplace `index.html` et redéploie via Vercel.
